#include "skin.h"

#include <gdiplus.h>
#include <wincodec.h>
#include <windows.h>

#include <algorithm>
#include <cwctype>
#include <vector>

#include "gfx.h"

using namespace Gdiplus;

void PetImage::Reset() {
    if (dc && oldBitmap) {
        SelectObject(dc, oldBitmap);
        oldBitmap = nullptr;
    }
    if (dc) {
        DeleteDC(dc);
        dc = nullptr;
    }
    if (bitmap) {
        DeleteObject(bitmap);
        bitmap = nullptr;
    }
    bits = nullptr;
    width = height = 0;
}

bool CreateDib(int w, int h, PetImage& out) {
    if (w <= 0 || h <= 0) return false;
    out.Reset();

    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;  // 自上而下
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HBITMAP bmp = CreateDIBSection(nullptr, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bmp || !bits) {
        if (bmp) DeleteObject(bmp);
        return false;
    }
    HDC dc = CreateCompatibleDC(nullptr);
    if (!dc) {
        DeleteObject(bmp);
        return false;
    }
    HGDIOBJ old = SelectObject(dc, bmp);
    out.bitmap = bmp;
    out.oldBitmap = static_cast<HBITMAP>(old);
    out.dc = dc;
    out.bits = bits;
    out.width = w;
    out.height = h;
    return true;
}

void PremultiplyInPlace(void* bits, int w, int h) {
    auto* p = static_cast<BYTE*>(bits);
    const size_t count = static_cast<size_t>(w) * static_cast<size_t>(h);
    for (size_t i = 0; i < count; ++i, p += 4) {
        const unsigned a = p[3];
        if (a == 255) continue;
        if (a == 0) {
            p[0] = p[1] = p[2] = 0;
            continue;
        }
        p[0] = static_cast<BYTE>((p[0] * a + 127) / 255);
        p[1] = static_cast<BYTE>((p[1] * a + 127) / 255);
        p[2] = static_cast<BYTE>((p[2] * a + 127) / 255);
    }
}

std::wstring ExeDir() {
    wchar_t buf[MAX_PATH]{};
    DWORD n = GetModuleFileNameW(nullptr, buf, MAX_PATH);
    std::wstring path(buf, n);
    const size_t pos = path.find_last_of(L"\\/");
    if (pos == std::wstring::npos) return L".";
    return path.substr(0, pos);
}

std::wstring SkinFolderBesideExe() {
    return ExeDir() + L"\\skins";
}

std::wstring SkinFolderUser() {
    wchar_t buf[MAX_PATH]{};
    DWORD n = GetEnvironmentVariableW(L"APPDATA", buf, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return L"";
    std::wstring dir = std::wstring(buf) + L"\\MusicPet\\skins";
    CreateDirectoryW((std::wstring(buf) + L"\\MusicPet").c_str(), nullptr);
    CreateDirectoryW(dir.c_str(), nullptr);
    return dir;
}

std::wstring SkinFolderPreferred() {
    // 用户目录存在且能读到图片时优先；否则用程序目录，方便绿色版直接放图。
    const std::wstring user = SkinFolderUser();
    if (!user.empty()) {
        WIN32_FIND_DATAW fd{};
        HANDLE h = FindFirstFileW((user + L"\\*.png").c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            FindClose(h);
            return user;
        }
    }
    return SkinFolderBesideExe();
}

static std::wstring StemOf(const std::wstring& path) {
    const size_t slash = path.find_last_of(L"\\/");
    std::wstring name = (slash == std::wstring::npos) ? path : path.substr(slash + 1);
    const size_t dot = name.find_last_of(L'.');
    if (dot != std::wstring::npos) name = name.substr(0, dot);
    return name;
}

static void ScanOne(const std::wstring& dir, const std::wstring& tag, std::vector<SkinItem>& out) {
    if (dir.empty()) return;
    WIN32_FIND_DATAW fd{};
    HANDLE h = FindFirstFileW((dir + L"\\*.png").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        SkinItem item;
        item.path = dir + L"\\" + fd.cFileName;
        item.label = StemOf(fd.cFileName);
        if (!tag.empty()) item.label += tag;
        out.push_back(item);
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

std::vector<SkinItem> ScanSkins() {
    std::vector<SkinItem> items;
    ScanOne(SkinFolderBesideExe(), L"", items);
    ScanOne(SkinFolderUser(), L"（用户目录）", items);

    std::sort(items.begin(), items.end(), [](const SkinItem& a, const SkinItem& b) {
        return _wcsicmp(a.label.c_str(), b.label.c_str()) < 0;
    });
    return items;
}

bool LoadPngImage(const std::wstring& path, int maxW, int maxH, PetImage& out) {
    if (maxW < 8 || maxH < 8) return false;
    IWICImagingFactory* factory = nullptr;
    IWICBitmapDecoder* decoder = nullptr;
    IWICBitmapFrameDecode* frame = nullptr;
    IWICBitmapScaler* scaler = nullptr;
    IWICFormatConverter* converter = nullptr;
    bool ok = false;

    do {
        if (FAILED(CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                                    IID_PPV_ARGS(&factory))))
            break;
        if (FAILED(factory->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ,
                                                      WICDecodeMetadataCacheOnLoad, &decoder)))
            break;
        if (FAILED(decoder->GetFrame(0, &frame))) break;

        UINT srcW = 0, srcH = 0;
        if (FAILED(frame->GetSize(&srcW, &srcH)) || srcW == 0 || srcH == 0) break;

        const double scale = std::min(static_cast<double>(maxW) / srcW,
                                      static_cast<double>(maxH) / srcH);
        const double clamped = (scale > 6.0) ? 6.0 : scale;
        UINT dstW = static_cast<UINT>(std::max(1.0, srcW * clamped));
        UINT dstH = static_cast<UINT>(std::max(1.0, srcH * clamped));

        IWICBitmapSource* source = frame;
        if (dstW != srcW || dstH != srcH) {
            if (FAILED(factory->CreateBitmapScaler(&scaler))) break;
            if (FAILED(scaler->Initialize(frame, dstW, dstH, WICBitmapInterpolationModeFant))) break;
            source = scaler;
        }

        if (FAILED(factory->CreateFormatConverter(&converter))) break;
        if (FAILED(converter->Initialize(source, GUID_WICPixelFormat32bppPBGRA,
                                         WICBitmapDitherTypeNone, nullptr, 0.0,
                                         WICBitmapPaletteTypeCustom)))
            break;

        if (!CreateDib(static_cast<int>(dstW), static_cast<int>(dstH), out)) break;

        const UINT stride = dstW * 4;
        if (FAILED(converter->CopyPixels(nullptr, stride, stride * dstH,
                                         static_cast<BYTE*>(out.bits)))) {
            out.Reset();
            break;
        }
        ok = true;
    } while (false);

    if (converter) converter->Release();
    if (scaler) scaler->Release();
    if (frame) frame->Release();
    if (decoder) decoder->Release();
    if (factory) factory->Release();
    return ok;
}

bool BuildPlaceholderPet(int targetH, PetImage& out) {
    const int h = std::max(64, targetH);
    const int w = h;

    Bitmap bmp(w, h, PixelFormat32bppPARGB);
    if (bmp.GetLastStatus() != Ok) return false;

    {
        Graphics g(&bmp);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
        g.Clear(Color(0, 0, 0, 0));

        const float W = static_cast<float>(w);
        const float H = static_cast<float>(h);

        // 地面阴影
        SolidBrush shadow(Color(46, 30, 30, 60));
        g.FillEllipse(&shadow, W * 0.20f, H * 0.86f, W * 0.60f, H * 0.09f);

        // 耳朵
        GraphicsPath ears;
        ears.AddPolygon(std::vector<PointF>{
            PointF(W * 0.20f, H * 0.34f), PointF(W * 0.26f, H * 0.08f),
            PointF(W * 0.44f, H * 0.28f)}.data(), 3);
        ears.AddPolygon(std::vector<PointF>{
            PointF(W * 0.56f, H * 0.28f), PointF(W * 0.74f, H * 0.08f),
            PointF(W * 0.80f, H * 0.34f)}.data(), 3);
        SolidBrush earBrush(Color(255, 132, 168, 246));
        g.FillPath(&earBrush, &ears);

        // 身体
        LinearGradientBrush body(PointF(W * 0.5f, H * 0.16f), PointF(W * 0.5f, H * 0.92f),
                                 Color(255, 150, 186, 255), Color(255, 173, 148, 252));
        g.FillEllipse(&body, W * 0.10f, H * 0.17f, W * 0.80f, H * 0.74f);

        // 肚皮
        SolidBrush belly(Color(70, 255, 255, 255));
        g.FillEllipse(&belly, W * 0.26f, H * 0.54f, W * 0.48f, H * 0.30f);

        // 眼睛
        SolidBrush eye(Color(255, 46, 46, 66));
        g.FillEllipse(&eye, W * 0.33f, H * 0.44f, W * 0.10f, H * 0.12f);
        g.FillEllipse(&eye, W * 0.57f, H * 0.44f, W * 0.10f, H * 0.12f);
        SolidBrush glint(Color(230, 255, 255, 255));
        g.FillEllipse(&glint, W * 0.355f, H * 0.465f, W * 0.030f, H * 0.035f);
        g.FillEllipse(&glint, W * 0.595f, H * 0.465f, W * 0.030f, H * 0.035f);

        // 腮红
        SolidBrush blush(Color(70, 255, 130, 150));
        g.FillEllipse(&blush, W * 0.22f, H * 0.58f, W * 0.12f, H * 0.07f);
        g.FillEllipse(&blush, W * 0.66f, H * 0.58f, W * 0.12f, H * 0.07f);

        // 胸口音符，暗示"音乐桌宠"
        DrawNoteGlyph(g, W * 0.5f, H * 0.70f, H * 0.16f, 12.0f, Color(200, 255, 255, 255));
    }

    if (!CreateDib(w, h, out)) return false;

    Rect rc(0, 0, w, h);
    BitmapData bd{};
    if (bmp.LockBits(&rc, ImageLockModeRead, PixelFormat32bppPARGB, &bd) != Ok) {
        out.Reset();
        return false;
    }
    auto* dst = static_cast<BYTE*>(out.bits);
    for (int y = 0; y < h; ++y) {
        memcpy(dst + static_cast<size_t>(y) * w * 4,
               static_cast<BYTE*>(bd.Scan0) + static_cast<size_t>(y) * bd.Stride,
               static_cast<size_t>(w) * 4);
    }
    bmp.UnlockBits(&bd);
    return true;
}
