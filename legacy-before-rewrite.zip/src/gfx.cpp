#include "gfx.h"

using namespace Gdiplus;

// 设计尺寸按 100x100 计算：符头在下，符干向上，右侧一个符尾。
void DrawNoteGlyph(Graphics& g, float cx, float cy, float size, float angle, const Color& color) {
    const float s = size / 100.0f;
    if (s <= 0.0f) return;

    GraphicsState st = g.Save();
    g.TranslateTransform(cx, cy, MatrixOrderAppend);
    g.RotateTransform(angle, MatrixOrderAppend);
    g.ScaleTransform(s, s, MatrixOrderAppend);
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    g.SetPixelOffsetMode(PixelOffsetModeHighQuality);

    SolidBrush brush(color);

    // 符头（略微倾斜的椭圆）
    {
        GraphicsState h = g.Save();
        g.TranslateTransform(-2.0f, 22.0f, MatrixOrderAppend);
        g.RotateTransform(-22.0f, MatrixOrderAppend);
        g.FillEllipse(&brush, -21.0f, -13.0f, 42.0f, 26.0f);
        g.Restore(h);
    }

    // 符干
    g.FillRectangle(&brush, 12.0f, -44.0f, 7.0f, 62.0f);

    // 符尾（贝塞尔填充）
    GraphicsPath flag;
    flag.AddBezier(19.0f, -44.0f, 34.0f, -38.0f, 40.0f, -24.0f, 26.0f, -10.0f);
    flag.AddLine(26.0f, -10.0f, 19.0f, -16.0f);
    flag.AddBezier(30.0f, -26.0f, 30.0f, -36.0f, 26.0f, -39.0f, 19.0f, -40.0f);
    flag.CloseFigure();
    g.FillPath(&brush, &flag);

    g.Restore(st);
}
