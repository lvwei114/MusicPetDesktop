// 音符粒子层：独立的透明窗口，始终点击穿透。
#pragma once

#include <windows.h>

#include <gdiplus.h>

#include <random>
#include <vector>

struct NoteParticle {
    float x = 0.0f, y = 0.0f;
    float vx = 0.0f, vy = 0.0f;
    float rot = 0.0f, vrot = 0.0f;
    float size = 20.0f;
    float life = 0.0f, maxLife = 1.0f;
    float swayPhase = 0.0f, swayAmp = 0.0f;
    Gdiplus::Color color;
};

class NoteLayer {
public:
    ~NoteLayer();

    bool Create(HWND hwnd, int w, int h);
    bool Resize(int w, int h);

    void Configure(int density, float petScale);
    void SetOrigin(float cx, float cy, float radius);
    void SetPlaying(bool playing);
    void Preview(double seconds);

    bool Tick(double dt);   // 返回 true 表示这一帧仍有内容需要绘制
    void Render();
    void Hide();

    int Width() const { return m_w; }
    int Height() const { return m_h; }

private:
    void Spawn();
    void DrawFrame();

    HWND m_hwnd = nullptr;
    int m_w = 0, m_h = 0;
    HBITMAP m_dib = nullptr;
    HDC m_memDc = nullptr;
    void* m_bits = nullptr;
    Gdiplus::Bitmap* m_canvas = nullptr;

    std::vector<NoteParticle> m_particles;
    std::mt19937 m_rng{std::random_device{}()};

    bool m_playing = false;
    bool m_visible = false;
    double m_previewLeft = 0.0;
    double m_spawnAcc = 0.0;

    int m_density = 2;
    float m_petScale = 1.0f;
    float m_originX = 0.0f, m_originY = 0.0f, m_radius = 80.0f;
};
