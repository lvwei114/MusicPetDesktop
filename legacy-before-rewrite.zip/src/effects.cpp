#include "effects.h"

#include <algorithm>
#include <cmath>

#include "gfx.h"

using namespace Gdiplus;

static float Rand01(std::mt19937& rng) {
    return std::uniform_real_distribution<float>(0.0f, 1.0f)(rng);
}

static float FadeCurve(float t) {
    t = std::clamp(t, 0.0f, 1.0f);
    const float fadeIn = std::min(1.0f, t / 0.16f);
    const float fadeOut = std::min(1.0f, (1.0f - t) / 0.45f);
    return std::max(0.0f, std::min(fadeIn, fadeOut));
}

NoteLayer::~NoteLayer() {
    if (m_canvas) {
        delete m_canvas;
        m_canvas = nullptr;
    }
    if (m_memDc) {
        DeleteDC(m_memDc);
        m_memDc = nullptr;
    }
    if (m_dib) {
        DeleteObject(m_dib);
        m_dib = nullptr;
    }
}

bool NoteLayer::Create(HWND hwnd, int w, int h) {
    m_hwnd = hwnd;
    return Resize(w, h);
}

bool NoteLayer::Resize(int w, int h) {
    w = std::max(32, w);
    h = std::max(32, h);
    if (w == m_w && h == m_h && m_dib && m_canvas) return true;

    if (m_canvas) {
        delete m_canvas;
        m_canvas = nullptr;
    }
    if (m_memDc) {
        DeleteDC(m_memDc);
        m_memDc = nullptr;
    }
    if (m_dib) {
        DeleteObject(m_dib);
        m_dib = nullptr;
    }
    m_bits = nullptr;
    m_particles.clear();

    BITMAPINFO bi{};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = w;
    bi.bmiHeader.biHeight = -h;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;

    m_dib = CreateDIBSection(nullptr, &bi, DIB_RGB_COLORS, &m_bits, nullptr, 0);
    if (!m_dib || !m_bits) return false;

    m_memDc = CreateCompatibleDC(nullptr);
    if (!m_memDc) return false;
    SelectObject(m_memDc, m_dib);

    m_canvas = new Bitmap(w, h, PixelFormat32bppPARGB);
    if (m_canvas->GetLastStatus() != Ok) {
        delete m_canvas;
        m_canvas = nullptr;
        return false;
    }

    m_w = w;
    m_h = h;
    m_visible = false;
    return true;
}

void NoteLayer::Configure(int density, float petScale) {
    m_density = std::clamp(density, 0, 3);
    m_petScale = std::clamp(petScale, 0.5f, 2.5f);
}

void NoteLayer::SetOrigin(float cx, float cy, float radius) {
    m_originX = cx;
    m_originY = cy;
    m_radius = std::max(16.0f, radius);
}

void NoteLayer::SetPlaying(bool playing) { m_playing = playing; }

void NoteLayer::Preview(double seconds) { m_previewLeft = std::max(m_previewLeft, seconds); }

bool NoteLayer::Tick(double dt) {
    if (dt <= 0.0) dt = 0.016;
    if (dt > 0.25) dt = 0.25;

    if (m_previewLeft > 0.0) {
        m_previewLeft = std::max(0.0, m_previewLeft - dt);
    }

    const bool emitting = (m_playing || m_previewLeft > 0.0) && m_density > 0;
    if (emitting) {
        const double rate = (m_density == 1) ? 3.0 : (m_density == 3 ? 12.0 : 6.0);
        m_spawnAcc += dt * rate;
        int guard = 0;
        while (m_spawnAcc >= 1.0 && guard++ < 48) {
            m_spawnAcc -= 1.0;
            Spawn();
        }
    } else {
        m_spawnAcc = 0.0;
    }

    for (auto& p : m_particles) {
        p.life += static_cast<float>(dt);
        p.x += (p.vx + std::sin(p.swayPhase + p.life * 2.2f) * p.swayAmp) * static_cast<float>(dt);
        p.y += p.vy * static_cast<float>(dt);
        p.rot += p.vrot * static_cast<float>(dt);
    }

    m_particles.erase(std::remove_if(m_particles.begin(), m_particles.end(),
                                     [](const NoteParticle& p) { return p.life >= p.maxLife; }),
                      m_particles.end());

    return emitting || !m_particles.empty();
}

void NoteLayer::Spawn() {
    if (m_particles.size() > 140) return;

    NoteParticle p;
    const float angle = Rand01(m_rng) * 6.2831853f;
    const float radius = m_radius * (0.80f + Rand01(m_rng) * 0.45f);

    p.x = m_originX + std::cos(angle) * radius;
    p.y = m_originY + std::sin(angle) * radius * 0.85f;
    p.vx = (Rand01(m_rng) - 0.5f) * 26.0f;
    p.vy = -(26.0f + Rand01(m_rng) * 46.0f) * m_petScale;

    const float base = 24.0f * m_petScale;
    p.size = base * (0.65f + Rand01(m_rng) * 0.70f);
    p.maxLife = 2.0f + Rand01(m_rng) * 1.8f;
    p.rot = (Rand01(m_rng) - 0.5f) * 36.0f;
    p.vrot = (Rand01(m_rng) - 0.5f) * 70.0f;
    p.swayAmp = 6.0f + Rand01(m_rng) * 16.0f;
    p.swayPhase = Rand01(m_rng) * 6.2831853f;

    static const Color kPalette[] = {
        Color(255, 255, 255, 255), Color(255, 152, 202, 255), Color(255, 255, 172, 212),
        Color(255, 255, 220, 142), Color(255, 154, 255, 222),
    };
    p.color = kPalette[m_rng() % 5];

    m_particles.push_back(p);
}

void NoteLayer::DrawFrame() {
    Graphics g(m_canvas);
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    g.SetPixelOffsetMode(PixelOffsetModeHighQuality);
    g.Clear(Color(0, 0, 0, 0));

    for (const auto& p : m_particles) {
        const float t = p.life / p.maxLife;
        const float alpha = FadeCurve(t);
        if (alpha <= 0.01f) continue;

        const int a = static_cast<int>(alpha * p.color.GetA());
        if (a <= 1) continue;

        const Color c(static_cast<BYTE>(a), p.color.GetR(), p.color.GetG(), p.color.GetB());
        DrawNoteGlyph(g, p.x, p.y, p.size * (0.85f + 0.30f * t), p.rot, c);
    }
}

void NoteLayer::Render() {
    if (!m_hwnd || !m_canvas || !m_memDc) return;

    if (!m_visible) {
        ShowWindow(m_hwnd, SW_SHOWNOACTIVATE);
        m_visible = true;
    }

    DrawFrame();

    Rect rc(0, 0, m_w, m_h);
    BitmapData bd{};
    if (m_canvas->LockBits(&rc, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
        auto* dst = static_cast<BYTE*>(m_bits);
        for (int y = 0; y < m_h; ++y) {
            memcpy(dst + static_cast<size_t>(y) * m_w * 4,
                   static_cast<BYTE*>(bd.Scan0) + static_cast<size_t>(y) * bd.Stride,
                   static_cast<size_t>(m_w) * 4);
        }
        m_canvas->UnlockBits(&bd);
    }

    BLENDFUNCTION blend{AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    SIZE size{m_w, m_h};
    POINT src{0, 0};
    UpdateLayeredWindow(m_hwnd, nullptr, nullptr, &size, m_memDc, &src, 0, &blend, ULW_ALPHA);
}

void NoteLayer::Hide() {
    if (m_hwnd && m_visible) {
        ShowWindow(m_hwnd, SW_HIDE);
        m_visible = false;
    }
}
