#include "settings.h"

#include <shlobj.h>
#include <windows.h>

static std::wstring AppDataDir() {
    wchar_t buf[MAX_PATH]{};
    DWORD n = GetEnvironmentVariableW(L"APPDATA", buf, MAX_PATH);
    std::wstring dir = (n > 0 && n < MAX_PATH) ? std::wstring(buf) : std::wstring();
    if (dir.empty()) {
        // 兜底：当前用户目录下的 AppData\Roaming
        wchar_t profile[MAX_PATH]{};
        if (GetEnvironmentVariableW(L"USERPROFILE", profile, MAX_PATH) > 0) {
            dir = std::wstring(profile) + L"\\AppData\\Roaming";
        }
    }
    if (!dir.empty()) {
        dir += L"\\MusicPet";
        CreateDirectoryW(dir.c_str(), nullptr);
    }
    return dir;
}

std::wstring SettingsFilePath() {
    std::wstring dir = AppDataDir();
    if (dir.empty()) return L"MusicPet.ini";
    return dir + L"\\settings.ini";
}

static std::wstring ReadStr(const wchar_t* key, const std::wstring& def, const std::wstring& file) {
    wchar_t buf[1024]{};
    GetPrivateProfileStringW(L"pet", key, def.c_str(), buf, 1024, file.c_str());
    return std::wstring(buf);
}

void LoadSettings(Settings& s) {
    const std::wstring file = SettingsFilePath();
    s.skinPath = ReadStr(L"Skin", L"", file);
    s.petHeight = GetPrivateProfileIntW(L"pet", L"Height", 200, file.c_str());
    if (s.petHeight < 64) s.petHeight = 64;
    if (s.petHeight > 900) s.petHeight = 900;

    {
        // 用字符串读取，避免无符号默认值转换问题
        std::wstring x = ReadStr(L"X", L"", file);
        std::wstring y = ReadStr(L"Y", L"", file);
        s.posX = x.empty() ? INT_MIN : (int)wcstol(x.c_str(), nullptr, 10);
        s.posY = y.empty() ? INT_MIN : (int)wcstol(y.c_str(), nullptr, 10);
    }
    s.clickThrough = GetPrivateProfileIntW(L"pet", L"ClickThrough", 0, file.c_str()) != 0;
    s.locked = GetPrivateProfileIntW(L"pet", L"Locked", 0, file.c_str()) != 0;
    s.gameMode = GetPrivateProfileIntW(L"pet", L"GameMode", 0, file.c_str()) != 0;
    s.effectsOn = GetPrivateProfileIntW(L"pet", L"Effects", 1, file.c_str()) != 0 ? 1 : 0;
    s.density = GetPrivateProfileIntW(L"pet", L"Density", 2, file.c_str());
    if (s.density < 1) s.density = 1;
    if (s.density > 3) s.density = 3;
}

void SaveSettings(const Settings& s) {
    const std::wstring file = SettingsFilePath();
    WritePrivateProfileStringW(L"pet", L"Skin", s.skinPath.c_str(), file.c_str());
    WritePrivateProfileStringW(L"pet", L"Height", std::to_wstring(s.petHeight).c_str(), file.c_str());
    WritePrivateProfileStringW(L"pet", L"X", std::to_wstring(s.posX).c_str(), file.c_str());
    WritePrivateProfileStringW(L"pet", L"Y", std::to_wstring(s.posY).c_str(), file.c_str());
    WritePrivateProfileStringW(L"pet", L"ClickThrough", s.clickThrough ? L"1" : L"0", file.c_str());
    WritePrivateProfileStringW(L"pet", L"Locked", s.locked ? L"1" : L"0", file.c_str());
    WritePrivateProfileStringW(L"pet", L"GameMode", s.gameMode ? L"1" : L"0", file.c_str());
    WritePrivateProfileStringW(L"pet", L"Effects", s.effectsOn ? L"1" : L"0", file.c_str());
    WritePrivateProfileStringW(L"pet", L"Density", std::to_wstring(s.density).c_str(), file.c_str());
}
