#include "media.h"

#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Media.Control.h>
#include <winrt/base.h>

#include <algorithm>
#include <atomic>
#include <deque>
#include <mutex>

namespace wmc = winrt::Windows::Media::Control;
using wmc::GlobalSystemMediaTransportControlsSession;
using wmc::GlobalSystemMediaTransportControlsSessionManager;
using wmc::GlobalSystemMediaTransportControlsSessionPlaybackStatus;

static std::wstring Lowered(std::wstring s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](wchar_t c) { return static_cast<wchar_t>(towlower(c)); });
    return s;
}

// 把 AUMID / exe 名映射成用户看得懂的名字；未命中时原样返回。
static std::wstring FriendlyName(const std::wstring& raw) {
    if (raw.empty()) return L"未知播放器";
    const std::wstring lower = Lowered(raw);
    struct Map {
        const wchar_t* key;
        const wchar_t* name;
    };
    static const Map kMap[] = {
        {L"cloudmusic", L"网易云音乐"}, {L"qqmusic", L"QQ 音乐"},
        {L"kugou", L"酷狗音乐"},        {L"kwmusic", L"酷我音乐"},
        {L"spotify", L"Spotify"},       {L"musicfree", L"MusicFree"},
        {L"applemusic", L"Apple Music"}, {L"itunes", L"Apple Music"},
        {L"foobar", L"foobar2000"},     {L"vlc", L"VLC"},
        {L"potplayer", L"PotPlayer"},   {L"mpc-hc", L"MPC-HC"},
        {L"msedge", L"Edge 浏览器"},    {L"chrome", L"Chrome 浏览器"},
        {L"firefox", L"Firefox 浏览器"}, {L"brave", L"Brave 浏览器"},
    };
    for (const auto& e : kMap) {
        if (lower.find(e.key) != std::wstring::npos) return e.name;
    }
    return raw;
}

static PlayStatus MapStatus(GlobalSystemMediaTransportControlsSessionPlaybackStatus s) {
    switch (s) {
        case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Playing:
            return PlayStatus::Playing;
        case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Paused:
            return PlayStatus::Paused;
        case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Stopped:
        case GlobalSystemMediaTransportControlsSessionPlaybackStatus::Closed:
            return PlayStatus::Stopped;
        default:
            return PlayStatus::Unknown;
    }
}

struct MediaWatcher::Impl {
    HWND notify = nullptr;
    HANDLE thread = nullptr;
    HANDLE wake = nullptr;
    std::atomic<bool> stop{false};

    mutable std::mutex mutex;
    MediaSnapshot snap{};
    std::vector<SessionEntry> sessions;
    std::wstring selected;
    std::deque<MediaCommand> commands;

    // 以下仅工作线程访问
    GlobalSystemMediaTransportControlsSessionManager manager{nullptr};
    GlobalSystemMediaTransportControlsSession session{nullptr};
    uint64_t revision = 0;

    static DWORD WINAPI Trampoline(LPVOID param) {
        static_cast<Impl*>(param)->Run();
        return 0;
    }

    void Run() {
        winrt::init_apartment(winrt::apartment_type::multi_threaded);
        while (!stop.load()) {
            try {
                Tick();
            } catch (winrt::hresult_error const&) {
                // 播放器退出、会话失效等：下一轮重试
            } catch (...) {
            }
            WaitForSingleObject(wake, 400);
            ResetEvent(wake);
        }
        session = nullptr;
        manager = nullptr;
        winrt::uninit_apartment();
    }

    void DrainCommands() {
        std::deque<MediaCommand> pending;
        {
            std::lock_guard<std::mutex> lock(mutex);
            pending.swap(commands);
        }
        if (!session) return;
        for (MediaCommand cmd : pending) {
            try {
                switch (cmd) {
                    case CMD_TOGGLE: session.TryTogglePlayPauseAsync().get(); break;
                    case CMD_NEXT: session.TrySkipNextAsync().get(); break;
                    case CMD_PREV: session.TrySkipPreviousAsync().get(); break;
                }
            } catch (...) {
            }
        }
    }

    void Tick() {
        if (!manager) {
            manager = GlobalSystemMediaTransportControlsSessionManager::RequestAsync().get();
            if (!manager) return;
        }

        const auto list = manager.GetSessions();
        const uint32_t count = list.Size();

        std::wstring wantSelected;
        {
            std::lock_guard<std::mutex> lock(mutex);
            wantSelected = selected;
        }

        std::vector<SessionEntry> entries;
        std::vector<GlobalSystemMediaTransportControlsSession> objects;
        entries.reserve(count);
        objects.reserve(count);

        GlobalSystemMediaTransportControlsSession chosen{nullptr};
        GlobalSystemMediaTransportControlsSession firstPlaying{nullptr};

        for (uint32_t i = 0; i < count; ++i) {
            GlobalSystemMediaTransportControlsSession s{nullptr};
            try {
                s = list.GetAt(i);
            } catch (...) {
                continue;
            }
            if (!s) continue;

            SessionEntry entry;
            // 该接口没有独立的会话 Id，用 AUMID 作为标识；同应用多会话时退化为序号。
            try {
                entry.id = s.SourceAppUserModelId().c_str();
            } catch (...) {
            }
            if (entry.id.empty()) entry.id = L"session#" + std::to_wstring(i);
            entry.appName = FriendlyName(entry.id);
            try {
                auto info = s.GetPlaybackInfo();
                entry.playing = MapStatus(info.PlaybackStatus()) == PlayStatus::Playing;
            } catch (...) {
            }

            if (entry.playing && !firstPlaying) firstPlaying = s;
            if (!wantSelected.empty() && entry.id == wantSelected) chosen = s;

            objects.push_back(s);
            entries.push_back(entry);
        }

        if (!chosen) {
            try {
                chosen = manager.GetCurrentSession();
            } catch (...) {
                chosen = nullptr;
            }
        }
        if (!chosen) chosen = firstPlaying;
        session = chosen;

        DrainCommands();

        MediaSnapshot next;
        if (session) {
            try {
                next.valid = true;
                next.appId = session.SourceAppUserModelId().c_str();
                next.sessionId = next.appId;
                if (next.sessionId.empty()) next.sessionId = L"session#0";
                next.appName = FriendlyName(next.appId);
            } catch (...) {
                next.valid = false;
            }
        }

        if (next.valid) {
            try {
                auto info = session.GetPlaybackInfo();
                next.status = MapStatus(info.PlaybackStatus());
                auto controls = info.Controls();
                next.canToggle = controls.IsPlayPauseToggleEnabled();
                next.canNext = controls.IsNextEnabled();
                next.canPrev = controls.IsPreviousEnabled();
            } catch (...) {
            }
            try {
                auto props = session.TryGetMediaPropertiesAsync().get();
                next.title = props.Title().c_str();
                next.artist = props.Artist().c_str();
            } catch (...) {
            }
            try {
                auto timeline = session.GetTimelineProperties();
                const double start = timeline.StartTime().count() / 10000000.0;
                const double end = timeline.EndTime().count() / 10000000.0;
                const double pos = timeline.Position().count() / 10000000.0;
                next.durationSec = std::max(0.0, end - start);
                next.positionSec = std::clamp(pos - start, 0.0, next.durationSec);
            } catch (...) {
            }
        }

        bool changed = false;
        MediaSnapshot published;
        {
            std::lock_guard<std::mutex> lock(mutex);
            changed = (next.valid != snap.valid) || (next.sessionId != snap.sessionId) ||
                      (next.status != snap.status) || (next.title != snap.title) ||
                      (next.artist != snap.artist) || (next.canToggle != snap.canToggle) ||
                      (next.canNext != snap.canNext) || (next.canPrev != snap.canPrev);
            if (changed) ++revision;
            next.revision = changed ? revision : snap.revision;
            snap = next;
            sessions = entries;
            published = snap;
        }

        if (changed && notify) {
            PostMessageW(notify, WM_APP_MEDIA_UPDATE, 0, 0);
        }
    }
};

MediaWatcher::MediaWatcher() : m_impl(new Impl()) {}

MediaWatcher::~MediaWatcher() { Stop(); }

void MediaWatcher::Start(HWND notify) {
    if (m_impl->thread) return;
    m_impl->notify = notify;
    m_impl->stop.store(false);
    m_impl->wake = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!m_impl->wake) return;
    m_impl->thread = CreateThread(nullptr, 0, &Impl::Trampoline, m_impl.get(), 0, nullptr);
}

void MediaWatcher::Stop() {
    if (!m_impl || !m_impl->thread) return;
    m_impl->stop.store(true);
    if (m_impl->wake) SetEvent(m_impl->wake);
    WaitForSingleObject(m_impl->thread, 3000);
    CloseHandle(m_impl->thread);
    m_impl->thread = nullptr;
    if (m_impl->wake) {
        CloseHandle(m_impl->wake);
        m_impl->wake = nullptr;
    }
}

MediaSnapshot MediaWatcher::Snapshot() const {
    std::lock_guard<std::mutex> lock(m_impl->mutex);
    return m_impl->snap;
}

std::vector<SessionEntry> MediaWatcher::Sessions() const {
    std::lock_guard<std::mutex> lock(m_impl->mutex);
    return m_impl->sessions;
}

std::wstring MediaWatcher::SelectedId() const {
    std::lock_guard<std::mutex> lock(m_impl->mutex);
    return m_impl->selected;
}

void MediaWatcher::Select(const std::wstring& sessionId) {
    {
        std::lock_guard<std::mutex> lock(m_impl->mutex);
        m_impl->selected = sessionId;
    }
    if (m_impl->wake) SetEvent(m_impl->wake);
}

void MediaWatcher::Send(MediaCommand cmd) {
    {
        std::lock_guard<std::mutex> lock(m_impl->mutex);
        m_impl->commands.push_back(cmd);
    }
    if (m_impl->wake) SetEvent(m_impl->wake);
}
