// 音乐桌宠：静态图片 + GSMTC 播放状态 + 音符粒子。
// 两个分层窗口：桌宠窗口（可交互）与音符窗口（始终点击穿透）。

#include <windows.h>

#include <gdiplus.h>
#include <shellapi.h>

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "app.h"
#include "effects.h"
#include "gfx.h"
#include "media.h"
#include "settings.h"
#include "skin.h"

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "windowsapp.lib")

using namespace Gdiplus;

namespace {

const wchar_t* kPetClass = L"MusicPetWnd";
const wchar_t* kFxClass = L"MusicPetFxWnd";

constexpr UINT_PTR kAnimTimer = 1;
constexpr UINT_PTR kQuitTimer = 2;
constexpr UINT kAnimIntervalMs = 33;

constexpr int kHotkeyThrough = 1;
constexpr int kHotkeyNextSkin = 2;
constexpr int kHotkeyEffects = 3;

constexpr int kCmdExit = 100;
constexpr int kCmdTogglePlay = 101;
constexpr int kCmdNext = 102;
constexpr int kCmdPrev = 103;
constexpr int kCmdPreview = 110;
constexpr int kCmdOpenFolder = 120;
constexpr int kCmdRescan = 121;
constexpr int kCmdDefaultSkin = 122;
constexpr int kCmdEffects = 130;
constexpr int kCmdClickThrough = 140;
constexpr int kCmdLock = 141;
constexpr int kCmdGameMode = 142;
constexpr int kCmdAutoSelect = 150;
constexpr int kCmdDensity1 = 160;
constexpr int kCmdDensity2 = 161;
constexpr int kCmdDensity3 = 162;
constexpr int kCmdSizeS = 170;
constexpr int kCmdSizeM = 171;
constexpr int kCmdSizeL = 172;
constexpr int kCmdSkinBase = 1000;
constexpr int kCmdSessionBase = 2000;

struct App {
    HINSTANCE inst = nullptr;
    HWND pet = nullptr;
    HWND fx = nullptr;
    UINT dpi = 96;

    Settings settings;
    std::vector<SkinItem> skins;
    int skinIndex = -1;
    std::wstring skinPath;
    PetImage image;

    NoteLayer notes;
    MediaWatcher media;
    MediaSnapshot snapshot;

    HICON tray = nullptr;
    bool trayAdded = false;

    bool animating = false;
    bool dragging = false;
    bool positioned = false;
    POINT dragOffset{};
    ULONGLONG lastTick = 0;
};

App g;

// 轻量启动日志（%TEMP%\MusicPet.log），便于排查"没出现/没退出"这类问题。
void Log(const char* msg) {
    wchar_t temp[MAX_PATH]{};
    if (!GetTempPathW(MAX_PATH, temp)) return;
    const std::wstring path = std::wstring(temp) + L"MusicPet.log";

    SYSTEMTIME st{};
    GetLocalTime(&st);
    char line[512]{};
    sprintf_s(line, "[%02d:%02d:%02d.%03d] %s\r\n", st.wHour, st.wMinute, st.wSecond,
              st.wMilliseconds, msg);

    HANDLE h = CreateFileW(path.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                           nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) return;
    SetFilePointer(h, 0, nullptr, FILE_END);
    DWORD written = 0;
    WriteFile(h, line, static_cast<DWORD>(strlen(line)), &written, nullptr);
    CloseHandle(h);
}

int Scale(int v) { return MulDiv(v, static_cast<int>(g.dpi), 96); }

std::wstring FormatTime(double seconds) {
    if (seconds < 0.0) seconds = 0.0;
    const int total = static_cast<int>(seconds);
    wchar_t buf[32]{};
    swprintf_s(buf, L"%d:%02d", total / 60, total % 60);
    return buf;
}

void SavePosition() {
    // 位置在 PlacePet 时已同步到 settings，这里只负责落盘。
    SaveSettings(g.settings);
}

void PlacePet(int x, int y, int w, int h) {
    if (!g.pet) return;

    g.settings.posX = x;
    g.settings.posY = y;

    SetWindowPos(g.pet, HWND_TOPMOST, x, y, w, h, SWP_NOACTIVATE);

    const int marginX = Scale(170);
    const int marginTop = Scale(300);
    const int marginBottom = Scale(90);
    const int fxW = w + marginX * 2;
    const int fxH = h + marginTop + marginBottom;
    const int fxX = x - marginX;
    const int fxY = y - marginTop;

    if (g.fx) {
        SetWindowPos(g.fx, HWND_TOPMOST, fxX, fxY, fxW, fxH, SWP_NOACTIVATE);
        g.notes.Resize(fxW, fxH);
        g.notes.SetOrigin(static_cast<float>(x + w / 2 - fxX),
                          static_cast<float>(y + h / 2 - fxY),
                          static_cast<float>(std::max(40, w / 2)));
        g.notes.Configure(g.settings.effectsOn ? g.settings.density : 0,
                          static_cast<float>(h) / 200.0f);
    }

    // 让桌宠保持在音符层之上
    SetWindowPos(g.pet, HWND_TOPMOST, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

    {
        RECT pr{}, fr{};
        GetWindowRect(g.pet, &pr);
        GetWindowRect(g.fx, &fr);
        char buf[256]{};
        sprintf_s(buf, "layout pet=%ld,%ld %ldx%ld fx=%ld,%ld %ldx%ld", pr.left, pr.top,
                  pr.right - pr.left, pr.bottom - pr.top, fr.left, fr.top, fr.right - fr.left,
                  fr.bottom - fr.top);
        Log(buf);
    }
}

void UpdatePetContent() {
    if (!g.pet || !g.image.dc) return;

    RECT r{};
    GetWindowRect(g.pet, &r);

    HDC screen = GetDC(nullptr);
    POINT dst{r.left, r.top};
    SIZE size{g.image.width, g.image.height};
    POINT src{0, 0};
    BLENDFUNCTION blend{AC_SRC_OVER, 0, 255, AC_SRC_ALPHA};
    const BOOL ok = UpdateLayeredWindow(g.pet, screen, &dst, &size, g.image.dc, &src, 0, &blend,
                                        ULW_ALPHA);
    const DWORD err = GetLastError();
    ReleaseDC(nullptr, screen);

    char buf[256]{};
    sprintf_s(buf, "layered ok=%d err=%lu at %ld,%ld size=%dx%d", ok, err, dst.x, dst.y,
              (int)size.cx, (int)size.cy);
    Log(buf);

    ShowWindow(g.pet, SW_SHOWNOACTIVATE);
    sprintf_s(buf, "visible=%d", IsWindowVisible(g.pet));
    Log(buf);
}

POINT DefaultPetPos(int w, int h) {
    RECT work{};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    POINT pt;
    pt.x = work.left + (work.right - work.left - w) / 2;
    pt.y = work.top + (work.bottom - work.top - h) / 2;
    char buf[192]{};
    sprintf_s(buf, "workarea=%ld,%ld %ldx%ld -> default %ld,%ld", work.left, work.top,
              work.right - work.left, work.bottom - work.top, pt.x, pt.y);
    Log(buf);
    return pt;
}

bool IsPointOnAnyMonitor(int x, int y) {
    POINT pt{x, y};
    return MonitorFromPoint(pt, MONITOR_DEFAULTTONULL) != nullptr;
}

void ApplyClickThrough() {
    if (!g.pet) return;
    LONG_PTR ex = GetWindowLongPtrW(g.pet, GWL_EXSTYLE);
    if (g.settings.clickThrough) {
        ex |= WS_EX_TRANSPARENT;
    } else {
        ex &= ~WS_EX_TRANSPARENT;
    }
    ex |= WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW | WS_EX_LAYERED;
    SetWindowLongPtrW(g.pet, GWL_EXSTYLE, ex);
    SetWindowPos(g.pet, nullptr, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED);
}

bool ApplySkin(const std::wstring& path) {
    const int targetH = Scale(g.settings.petHeight);

    PetImage img;
    bool ok = false;
    if (!path.empty()) ok = LoadPngImage(path, targetH, targetH, img);
    if (!ok) ok = BuildPlaceholderPet(targetH, img);
    if (!ok) return false;

    RECT oldRect{};
    const bool had = g.positioned && g.pet && GetWindowRect(g.pet, &oldRect);
    const int cx = had ? (oldRect.left + oldRect.right) / 2 : 0;
    const int cy = had ? (oldRect.top + oldRect.bottom) / 2 : 0;

    g.image.Reset();
    g.image = img;

    const int w = img.width;
    const int h = img.height;

    POINT pos;
    if (had) {
        pos.x = cx - w / 2;
        pos.y = cy - h / 2;
    } else if (g.settings.posX != INT_MIN && g.settings.posY != INT_MIN &&
               IsPointOnAnyMonitor(g.settings.posX, g.settings.posY)) {
        pos.x = g.settings.posX;
        pos.y = g.settings.posY;
        char buf[128]{};
        sprintf_s(buf, "using saved pos %d,%d", pos.x, pos.y);
        Log(buf);
    } else {
        pos = DefaultPetPos(w, h);
        g.settings.posX = pos.x;
        g.settings.posY = pos.y;
    }

    PlacePet(pos.x, pos.y, w, h);
    g.positioned = true;
    UpdatePetContent();

    // 统计非透明像素，确认占位形象确实画出来了
    {
        const auto* px = static_cast<const BYTE*>(g.image.bits);
        size_t opaque = 0;
        const size_t total = static_cast<size_t>(g.image.width) * g.image.height;
        for (size_t i = 0; i < total; ++i) {
            if (px[i * 4 + 3] > 8) ++opaque;
        }
        char buf[160]{};
        sprintf_s(buf, "skin applied: %dx%d opaque=%.1f%%", g.image.width, g.image.height,
                  total ? 100.0 * opaque / total : 0.0);
        Log(buf);
    }
    return true;
}

void StartAnim() {
    if (g.animating || !g.pet) return;
    g.animating = true;
    g.lastTick = 0;
    SetTimer(g.pet, kAnimTimer, kAnimIntervalMs, nullptr);
}

void StopAnim() {
    if (!g.animating || !g.pet) return;
    KillTimer(g.pet, kAnimTimer);
    g.animating = false;
    g.notes.Hide();
}

void Animate() {
    const ULONGLONG now = GetTickCount64();
    double dt = g.lastTick ? static_cast<double>(now - g.lastTick) / 1000.0 : 0.033;
    g.lastTick = now;
    if (dt > 0.2) dt = 0.2;

    const bool effects = g.settings.effectsOn != 0;
    const bool playing = g.snapshot.status == PlayStatus::Playing;
    g.notes.SetPlaying(playing && effects);

    if (g.notes.Tick(dt)) {
        g.notes.Render();
    } else {
        StopAnim();
    }
}

std::wstring ShortForTip(const std::wstring& s, size_t limit) {
    if (s.size() <= limit) return s;
    return s.substr(0, limit) + L"…";
}

void UpdateTrayTip() {
    if (!g.trayAdded || !g.pet) return;

    std::wstring tip = L"音乐桌宠";
    if (g.snapshot.valid) {
        tip = g.snapshot.appName;
        if (!g.snapshot.title.empty()) tip += L" · " + g.snapshot.title;
    } else {
        tip += L"（未检测到播放器）";
    }

    NOTIFYICONDATAW nid{};
    nid.cbSize = sizeof(nid);
    nid.hWnd = g.pet;
    nid.uID = 1;
    nid.uFlags = NIF_TIP;
    wcsncpy_s(nid.szTip, tip.c_str(), _TRUNCATE);
    Shell_NotifyIconW(NIM_MODIFY, &nid);
}

HICON MakeTrayIcon(int size) {
    PetImage img;
    if (!CreateDib(size, size, img)) return LoadIconW(nullptr, IDI_APPLICATION);

    {
        // 先画到 PARGB 位图，再拷进 DIB：直接用 HDC 画会拿不到正确的 Alpha。
        Bitmap canvas(size, size, PixelFormat32bppPARGB);
        if (canvas.GetLastStatus() == Ok) {
            Graphics gfx(&canvas);
            gfx.SetSmoothingMode(SmoothingModeAntiAlias);
            gfx.SetPixelOffsetMode(PixelOffsetModeHighQuality);
            gfx.Clear(Color(0, 0, 0, 0));
            SolidBrush circle(Color(255, 96, 140, 246));
            gfx.FillEllipse(&circle, 1.0f, 1.0f, static_cast<float>(size) - 2.0f,
                            static_cast<float>(size) - 2.0f);
            DrawNoteGlyph(gfx, size * 0.52f, size * 0.54f, size * 0.62f, 10.0f,
                          Color(255, 255, 255, 255));

            Rect rc(0, 0, size, size);
            BitmapData bd{};
            if (canvas.LockBits(&rc, ImageLockModeRead, PixelFormat32bppPARGB, &bd) == Ok) {
                auto* dst = static_cast<BYTE*>(img.bits);
                for (int y = 0; y < size; ++y) {
                    memcpy(dst + static_cast<size_t>(y) * size * 4,
                           static_cast<BYTE*>(bd.Scan0) + static_cast<size_t>(y) * bd.Stride,
                           static_cast<size_t>(size) * 4);
                }
                canvas.UnlockBits(&bd);
            }
        }
    }

    HBITMAP mask = CreateBitmap(size, size, 1, 1, nullptr);
    ICONINFO info{};
    info.fIcon = TRUE;
    info.hbmMask = mask;
    info.hbmColor = img.bitmap;
    HICON icon = CreateIconIndirect(&info);
    if (mask) DeleteObject(mask);
    img.Reset();
    return icon ? icon : LoadIconW(nullptr, IDI_APPLICATION);
}

void AddTray() {
    if (g.trayAdded || !g.pet) return;

    NOTIFYICONDATAW nid{};
    nid.cbSize = sizeof(nid);
    nid.hWnd = g.pet;
    nid.uID = 1;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_APP_TRAY;
    nid.hIcon = MakeTrayIcon(GetSystemMetrics(SM_CXSMICON));
    if (!nid.hIcon) nid.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wcscpy_s(nid.szTip, L"音乐桌宠");
    Shell_NotifyIconW(NIM_ADD, &nid);
    g.tray = nid.hIcon;
    g.trayAdded = true;
    UpdateTrayTip();
}

void RemoveTray() {
    if (!g.trayAdded || !g.pet) return;
    NOTIFYICONDATAW nid{};
    nid.cbSize = sizeof(nid);
    nid.hWnd = g.pet;
    nid.uID = 1;
    Shell_NotifyIconW(NIM_DELETE, &nid);
    g.trayAdded = false;
    if (g.tray) {
        DestroyIcon(g.tray);
        g.tray = nullptr;
    }
}

void OpenSkinFolder() {
    std::wstring dir = SkinFolderUser();
    if (dir.empty()) dir = SkinFolderBesideExe();
    CreateDirectoryW(dir.c_str(), nullptr);
    ShellExecuteW(nullptr, L"open", dir.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void RebuildSkinList() {
    g.skins = ScanSkins();
    g.skinIndex = -1;
    for (size_t i = 0; i < g.skins.size(); ++i) {
        if (!g.skinPath.empty() && _wcsicmp(g.skins[i].path.c_str(), g.skinPath.c_str()) == 0) {
            g.skinIndex = static_cast<int>(i);
            break;
        }
    }
}

void SelectSkin(int index) {
    if (index < 0 || index >= static_cast<int>(g.skins.size())) {
        g.skinPath.clear();
        g.skinIndex = -1;
    } else {
        g.skinPath = g.skins[index].path;
        g.skinIndex = index;
    }
    g.settings.skinPath = g.skinPath;
    ApplySkin(g.skinPath);
    SaveSettings(g.settings);
}

void CycleSkin() {
    if (g.skins.empty()) {
        SelectSkin(-1);
        return;
    }
    int next = g.skinIndex + 1;
    if (next >= static_cast<int>(g.skins.size())) next = -1;
    SelectSkin(next);
}

HMENU BuildMenu() {
    const MediaSnapshot s = g.snapshot;
    const auto sessions = g.media.Sessions();
    const std::wstring selected = g.media.SelectedId();

    HMENU menu = CreatePopupMenu();

    std::wstring now = L"未检测到播放器";
    if (s.valid) {
        now = s.appName + L" · " + (s.title.empty() ? L"未知曲目" : s.title);
    }
    AppendMenuW(menu, MF_STRING | MF_DISABLED, 0, ShortForTip(now, 60).c_str());

    if (s.valid && s.durationSec > 0.0) {
        std::wstring progress = L"进度 " + FormatTime(s.positionSec) + L" / " + FormatTime(s.durationSec);
        if (!s.artist.empty()) progress = s.artist + L"   " + progress;
        AppendMenuW(menu, MF_STRING | MF_DISABLED, 0, ShortForTip(progress, 60).c_str());
    }

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);

    HMENU players = CreatePopupMenu();
    AppendMenuW(players, MF_STRING | (selected.empty() ? MF_CHECKED : 0),
                kCmdAutoSelect, L"自动选择（跟随系统）");
    AppendMenuW(players, MF_SEPARATOR, 0, nullptr);
    if (sessions.empty()) {
        AppendMenuW(players, MF_STRING | MF_DISABLED, 0, L"（没有可用的媒体会话）");
    } else {
        for (size_t i = 0; i < sessions.size(); ++i) {
            std::wstring label = sessions[i].appName + (sessions[i].playing ? L"   ▶" : L"");
            const UINT flags = MF_STRING | ((selected == sessions[i].id) ? MF_CHECKED : 0);
            AppendMenuW(players, flags, kCmdSessionBase + static_cast<int>(i), label.c_str());
        }
    }
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(players), L"播放器");

    AppendMenuW(menu, MF_STRING | (s.canToggle ? 0 : MF_GRAYED), kCmdTogglePlay, L"播放 / 暂停");
    AppendMenuW(menu, MF_STRING | (s.canPrev ? 0 : MF_GRAYED), kCmdPrev, L"上一首");
    AppendMenuW(menu, MF_STRING | (s.canNext ? 0 : MF_GRAYED), kCmdNext, L"下一首");

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);

    HMENU skins = CreatePopupMenu();
    if (g.skins.empty()) {
        AppendMenuW(skins, MF_STRING | MF_DISABLED, 0, L"（还没有图片）");
    } else {
        for (size_t i = 0; i < g.skins.size(); ++i) {
            const UINT flags = MF_STRING | ((g.skinIndex == static_cast<int>(i)) ? MF_CHECKED : 0);
            AppendMenuW(skins, flags, kCmdSkinBase + static_cast<int>(i), g.skins[i].label.c_str());
        }
    }
    AppendMenuW(skins, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(skins, MF_STRING | (g.skinIndex < 0 ? MF_CHECKED : 0), kCmdDefaultSkin,
                L"内置形象");
    AppendMenuW(skins, MF_STRING, kCmdRescan, L"重新扫描图片");
    AppendMenuW(skins, MF_STRING, kCmdOpenFolder, L"打开图片文件夹");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(skins), L"切换桌宠形象");

    HMENU effects = CreatePopupMenu();
    AppendMenuW(effects, MF_STRING | (g.settings.effectsOn ? MF_CHECKED : 0), kCmdEffects,
                L"显示音符");
    AppendMenuW(effects, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(effects, MF_STRING | (g.settings.density == 1 ? MF_CHECKED : 0), kCmdDensity1,
                L"稀疏");
    AppendMenuW(effects, MF_STRING | (g.settings.density == 2 ? MF_CHECKED : 0), kCmdDensity2,
                L"正常");
    AppendMenuW(effects, MF_STRING | (g.settings.density == 3 ? MF_CHECKED : 0), kCmdDensity3,
                L"密集");
    AppendMenuW(effects, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(effects, MF_STRING, kCmdPreview, L"预览音符（5 秒）");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(effects), L"音符效果");

    HMENU size = CreatePopupMenu();
    AppendMenuW(size, MF_STRING | (g.settings.petHeight <= 160 ? MF_CHECKED : 0), kCmdSizeS, L"小");
    AppendMenuW(size, MF_STRING | (g.settings.petHeight > 160 && g.settings.petHeight <= 240 ? MF_CHECKED : 0),
                kCmdSizeM, L"中");
    AppendMenuW(size, MF_STRING | (g.settings.petHeight > 240 ? MF_CHECKED : 0), kCmdSizeL, L"大");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(size), L"桌宠大小");

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING | (g.settings.clickThrough ? MF_CHECKED : 0), kCmdClickThrough,
                L"点击穿透");
    AppendMenuW(menu, MF_STRING | (g.settings.locked ? MF_CHECKED : 0), kCmdLock, L"锁定位置");
    AppendMenuW(menu, MF_STRING | (g.settings.gameMode ? MF_CHECKED : 0), kCmdGameMode,
                L"游戏模式");

    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, kCmdExit, L"退出");
    return menu;
}

void ShowMenu() {
    POINT pt{};
    GetCursorPos(&pt);

    HMENU menu = BuildMenu();
    if (!menu) return;

    SetForegroundWindow(g.pet);
    const int cmd = static_cast<int>(TrackPopupMenu(
        menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY, pt.x, pt.y, 0, g.pet, nullptr));
    DestroyMenu(menu);
    PostMessageW(g.pet, WM_NULL, 0, 0);

    if (cmd > 0) {
        // 转发给统一处理
        PostMessageW(g.pet, WM_COMMAND, MAKEWPARAM(cmd, 0), 0);
    }
}

void HandleCommand(int id) {
    if (id >= kCmdSessionBase && id < kCmdSessionBase + 1000) {
        const auto sessions = g.media.Sessions();
        const size_t index = static_cast<size_t>(id - kCmdSessionBase);
        if (index < sessions.size()) g.media.Select(sessions[index].id);
        return;
    }
    if (id >= kCmdSkinBase && id < kCmdSkinBase + 1000) {
        SelectSkin(id - kCmdSkinBase);
        return;
    }

    switch (id) {
        case kCmdTogglePlay:
            g.media.Send(CMD_TOGGLE);
            break;
        case kCmdNext:
            g.media.Send(CMD_NEXT);
            break;
        case kCmdPrev:
            g.media.Send(CMD_PREV);
            break;
        case kCmdAutoSelect:
            g.media.Select(L"");
            break;
        case kCmdPreview:
            g.notes.Preview(5.0);
            StartAnim();
            break;
        case kCmdEffects:
            g.settings.effectsOn = g.settings.effectsOn ? 0 : 1;
            g.notes.Configure(g.settings.effectsOn ? g.settings.density : 0,
                              static_cast<float>(g.image.height) / 200.0f);
            g.notes.SetPlaying(false);
            SaveSettings(g.settings);
            break;
        case kCmdDensity1:
        case kCmdDensity2:
        case kCmdDensity3:
            g.settings.density = id - kCmdDensity1 + 1;
            g.notes.Configure(g.settings.effectsOn ? g.settings.density : 0,
                              static_cast<float>(g.image.height) / 200.0f);
            SaveSettings(g.settings);
            break;
        case kCmdSizeS:
        case kCmdSizeM:
        case kCmdSizeL: {
            static const int kHeights[] = {140, 200, 280};
            g.settings.petHeight = kHeights[id - kCmdSizeS];
            ApplySkin(g.skinPath);
            SaveSettings(g.settings);
            break;
        }
        case kCmdClickThrough:
            g.settings.clickThrough = !g.settings.clickThrough;
            ApplyClickThrough();
            SaveSettings(g.settings);
            break;
        case kCmdLock:
            g.settings.locked = !g.settings.locked;
            SaveSettings(g.settings);
            break;
        case kCmdGameMode:
            g.settings.gameMode = !g.settings.gameMode;
            if (g.settings.gameMode) {
                g.settings.clickThrough = true;
                g.settings.density = 1;
                ApplyClickThrough();
                g.notes.Configure(g.settings.effectsOn ? g.settings.density : 0,
                                  static_cast<float>(g.image.height) / 200.0f);
            }
            SaveSettings(g.settings);
            break;
        case kCmdRescan:
            RebuildSkinList();
            break;
        case kCmdOpenFolder:
            OpenSkinFolder();
            break;
        case kCmdDefaultSkin:
            SelectSkin(-1);
            break;
        case kCmdExit:
            DestroyWindow(g.pet);
            break;
        default:
            break;
    }
}

void OnMediaUpdate() {
    g.snapshot = g.media.Snapshot();
    UpdateTrayTip();
    if (g.snapshot.status == PlayStatus::Playing && g.settings.effectsOn) {
        StartAnim();
    }
}

LRESULT CALLBACK FxProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_NCHITTEST:
            return HTTRANSPARENT;
        case WM_ERASEBKGND:
            return 1;
        case WM_MOUSEACTIVATE:
            return MA_NOACTIVATE;
        default:
            return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

LRESULT CALLBACK PetProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_LBUTTONDOWN: {
            if (g.settings.locked) return 0;
            POINT pt{};
            GetCursorPos(&pt);
            RECT r{};
            GetWindowRect(hwnd, &r);
            g.dragOffset.x = pt.x - r.left;
            g.dragOffset.y = pt.y - r.top;
            g.dragging = true;
            SetCapture(hwnd);
            return 0;
        }
        case WM_MOUSEMOVE: {
            if (!g.dragging) return 0;
            POINT pt{};
            GetCursorPos(&pt);
            RECT r{};
            GetWindowRect(hwnd, &r);
            PlacePet(pt.x - g.dragOffset.x, pt.y - g.dragOffset.y, r.right - r.left,
                     r.bottom - r.top);
            return 0;
        }
        case WM_LBUTTONUP: {
            if (g.dragging) {
                g.dragging = false;
                ReleaseCapture();
                if (!g.settings.locked) {
                    SavePosition();
                }
            }
            return 0;
        }
        case WM_RBUTTONUP: {
            ShowMenu();
            return 0;
        }
        case WM_COMMAND: {
            HandleCommand(LOWORD(wParam));
            return 0;
        }
        case WM_TIMER: {
            if (wParam == kAnimTimer) {
                Animate();
                return 0;
            }
            if (wParam == kQuitTimer) {
                Log("quit timer");
                KillTimer(hwnd, kQuitTimer);
                DestroyWindow(hwnd);
                return 0;
            }
            return 0;
        }
        case WM_HOTKEY: {
            if (wParam == kHotkeyThrough) {
                g.settings.clickThrough = !g.settings.clickThrough;
                ApplyClickThrough();
                SaveSettings(g.settings);
            } else if (wParam == kHotkeyNextSkin) {
                CycleSkin();
            } else if (wParam == kHotkeyEffects) {
                g.settings.effectsOn = g.settings.effectsOn ? 0 : 1;
                g.notes.Configure(g.settings.effectsOn ? g.settings.density : 0,
                                  static_cast<float>(g.image.height) / 200.0f);
                g.notes.SetPlaying(false);
                SaveSettings(g.settings);
            }
            return 0;
        }
        case WM_APP_MEDIA_UPDATE: {
            OnMediaUpdate();
            return 0;
        }
        case WM_APP_TRAY: {
            const UINT ev = LOWORD(lParam);
            if (ev == WM_RBUTTONUP || ev == WM_CONTEXTMENU) {
                ShowMenu();
            } else if (ev == WM_LBUTTONDBLCLK) {
                g.settings.clickThrough = !g.settings.clickThrough;
                ApplyClickThrough();
                SaveSettings(g.settings);
            }
            return 0;
        }
        case WM_DPICHANGED: {
            g.dpi = HIWORD(wParam);
            ApplySkin(g.skinPath);
            return 0;
        }
        case WM_ERASEBKGND:
            return 1;
        case WM_DESTROY: {
            Log("destroy");
            SavePosition();
            StopAnim();
            RemoveTray();
            g.media.Stop();
            if (g.pet) {
                UnregisterHotKey(g.pet, kHotkeyThrough);
                UnregisterHotKey(g.pet, kHotkeyNextSkin);
                UnregisterHotKey(g.pet, kHotkeyEffects);
            }
            PostQuitMessage(0);
            return 0;
        }
        default:
            return DefWindowProcW(hwnd, msg, wParam, lParam);
    }
}

}  // namespace

int APIENTRY wWinMain(HINSTANCE inst, HINSTANCE, LPWSTR, int) {
    Log("boot");
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);

    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

    GdiplusStartupInput gdiInput;
    ULONG_PTR gdiToken = 0;
    if (GdiplusStartup(&gdiToken, &gdiInput, nullptr) != Ok) {
        MessageBoxW(nullptr, L"GDI+ 初始化失败。", L"音乐桌宠", MB_ICONERROR);
        return 1;
    }

    g.inst = inst;
    LoadSettings(g.settings);
    g.dpi = GetDpiForSystem();

    // 命令行：--preview 立即预览音符；--quit-after=毫秒 自动退出（用于自动化验证）
    DWORD quitAfter = 0;
    bool preview = false;
    {
        int argc = 0;
        LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
        if (argv) {
            for (int i = 1; i < argc; ++i) {
                const std::wstring a = argv[i];
                if (a == L"--preview") preview = true;
                else if (a.rfind(L"--quit-after=", 0) == 0) {
                    quitAfter = static_cast<DWORD>(_wtoi(a.c_str() + 13));
                }
            }
            LocalFree(argv);
        }
    }

    RebuildSkinList();
    g.skinPath = g.settings.skinPath;

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.hInstance = inst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpfnWndProc = FxProc;
    wc.lpszClassName = kFxClass;
    if (!RegisterClassExW(&wc)) {
        GdiplusShutdown(gdiToken);
        return 1;
    }
    wc.lpfnWndProc = PetProc;
    wc.lpszClassName = kPetClass;
    if (!RegisterClassExW(&wc)) {
        GdiplusShutdown(gdiToken);
        return 1;
    }

    g.fx = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TOPMOST,
        kFxClass, L"音乐桌宠-音符", WS_POPUP, 0, 0, 100, 100, nullptr, nullptr, inst, nullptr);
    if (!g.fx) {
        GdiplusShutdown(gdiToken);
        return 1;
    }

    g.pet = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE | WS_EX_TOPMOST, kPetClass,
        L"音乐桌宠", WS_POPUP, 0, 0, 100, 100, nullptr, nullptr, inst, nullptr);
    if (!g.pet) {
        GdiplusShutdown(gdiToken);
        return 1;
    }

    g.notes.Create(g.fx, 100, 100);
    ApplyClickThrough();
    {
        char buf[160]{};
        sprintf_s(buf, "windows created pet=%p fx=%p", (void*)g.pet, (void*)g.fx);
        Log(buf);
    }

    if (!ApplySkin(g.skinPath)) {
        Log("skin failed");
        MessageBoxW(nullptr, L"桌宠形象加载失败。", L"音乐桌宠", MB_ICONERROR);
        DestroyWindow(g.pet);
        GdiplusShutdown(gdiToken);
        return 1;
    }

    AddTray();
    Log("tray added");
    RegisterHotKey(g.pet, kHotkeyThrough, MOD_CONTROL | MOD_ALT, 'P');
    RegisterHotKey(g.pet, kHotkeyNextSkin, MOD_CONTROL | MOD_ALT, 'N');
    RegisterHotKey(g.pet, kHotkeyEffects, MOD_CONTROL | MOD_ALT, 'E');

    g.media.Start(g.pet);
    Log("media started");

    if (preview) {
        g.notes.Preview(6.0);
        StartAnim();
    }
    if (quitAfter > 0) {
        SetTimer(g.pet, kQuitTimer, quitAfter, nullptr);
    }

    MSG msg{};
    Log("message loop");
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    g.image.Reset();
    GdiplusShutdown(gdiToken);
    CoUninitialize();
    return 0;
}
