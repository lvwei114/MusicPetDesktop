// 桌宠形象：扫描 skins 目录、加载 PNG、内置占位形象。
#pragma once

#include <windows.h>
#include <string>
#include <vector>

struct SkinItem {
    std::wstring path;
    std::wstring label;
};

// 32 位预乘 Alpha 的 DIB（供 UpdateLayeredWindow 使用）
struct PetImage {
    HBITMAP bitmap = nullptr;
    HBITMAP oldBitmap = nullptr;
    HDC dc = nullptr;
    void* bits = nullptr;
    int width = 0;
    int height = 0;

    void Reset();
};

std::wstring ExeDir();
std::wstring SkinFolderBesideExe();
std::wstring SkinFolderUser();
std::wstring SkinFolderPreferred();   // 用户目录（不存在则回退到程序目录）

std::vector<SkinItem> ScanSkins();
bool LoadPngImage(const std::wstring& path, int maxW, int maxH, PetImage& out);
bool BuildPlaceholderPet(int targetH, PetImage& out);

bool CreateDib(int w, int h, PetImage& out);
void PremultiplyInPlace(void* bits, int w, int h);
